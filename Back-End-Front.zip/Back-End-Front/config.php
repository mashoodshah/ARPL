<?php

// Define DB Params
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "arpl");

// Define URL
define("ROOT_PATH", "/arpl/");
define("ROOT_URL", "http://localhost/arpl/");
